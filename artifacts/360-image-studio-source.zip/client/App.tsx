import { useCallback, useEffect, useRef, useState } from 'react';
import CanvasEditor from './components/CanvasEditor';
import ExportDialog from './components/ExportDialog';
import ImageDropZone from './components/ImageDropZone';
import LayerPanel from './components/LayerPanel';
import PromptBar from './components/PromptBar';
import Toolbar from './components/Toolbar';
import { downloadBlob } from './lib/canvas-exchange';
import { api } from './lib/api';
import { useProjectStore } from './stores/project';
import type { ProjectFile } from '../shared/types';
import FlatView from './views/FlatView';
import Viewer360 from './views/Viewer360';
import { useAuth } from './components/LoginGate';

function formatFileSize(bytes?: number) {
  if (!bytes) return '';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function App() {
  const { logout } = useAuth();
  const state = useProjectStore();
  const [activeTab, setActiveTab] = useState<'360' | 'flat'>('360');
  const [exportOpen, setExportOpen] = useState(false);
  const [isSavingProject, setIsSavingProject] = useState(false);
  const [isLoadingProject, setIsLoadingProject] = useState(false);
  const [loadingProjectName, setLoadingProjectName] = useState('');
  const [fileSize, setFileSize] = useState<number>();
  const saveInFlight = useRef(false);
  const imageInput = useRef<HTMLInputElement>(null);
  const projectInput = useRef<HTMLInputElement>(null);
  const fileMenuRef = useRef<HTMLDetailsElement>(null);
  const fileName = state.imagePath?.split('/').pop()?.split('\\').pop();
  const committed = state.layers.some((layer) => layer.status === 'committed');
  const closeFileMenu = () => {
    if (fileMenuRef.current) fileMenuRef.current.open = false;
  };

  useEffect(() => {
    const warnBeforeUnload = (event: BeforeUnloadEvent) => {
      if (!useProjectStore.getState().hasUnsavedChanges) return;
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', warnBeforeUnload);
    return () => window.removeEventListener('beforeunload', warnBeforeUnload);
  }, []);

  const openFile = useCallback(async (file: File) => {
    const meta = await api.image.upload(file);
    useProjectStore.getState().openImage(meta.path, meta.width, meta.height);
    setFileSize(file.size);
  }, []);

  const saveProject = useCallback(async () => {
    if (saveInFlight.current) return;
    const current = useProjectStore.getState();
    if (!current.imagePath) return;
    saveInFlight.current = true;
    setIsSavingProject(true);
    const project: ProjectFile = {
      version: 4,
      imagePath: current.imagePath,
      layers: current.layers,
      horizon: current.horizon,
    };
    try {
      const zipBlob = await api.project.download(project);
      const base = current.imagePath.split('/').pop()?.split('\\').pop()?.replace(/\.\w+$/, '') ?? 'project';
      downloadBlob(zipBlob, `${base}.360project`);
      useProjectStore.getState().markProjectSaved();
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    } finally {
      saveInFlight.current = false;
      setIsSavingProject(false);
    }
  }, []);

  const loadProject = useCallback(async (file: File) => {
    setIsLoadingProject(true);
    setLoadingProjectName(file.name);
    try {
      const { project } = await api.project.uploadZip(file);
      const meta = await api.image.open(project.imagePath);
      useProjectStore.getState().openImage(project.imagePath, meta.width, meta.height);
      useProjectStore.setState({
        layers: project.layers ?? [],
        horizon: project.horizon ?? { yaw: 0, pitch: 0, roll: 0 },
        hasUnsavedChanges: false,
      });
      setFileSize(meta.sizeBytes);
    } catch (err: any) {
      alert(`Load failed: ${err.message}`);
    } finally {
      setIsLoadingProject(false);
      setLoadingProjectName('');
    }
  }, []);

  const canvasWorkflow = ['canvas-edit', 'generating', 'ai-review'].includes(state.workflow);
  return (
    <div className="app-shell">
      <input ref={imageInput} hidden type="file" accept="image/*" onChange={(event) => {
        const file = event.target.files?.[0];
        if (file) void openFile(file);
        event.target.value = '';
      }} />
      <input ref={projectInput} hidden type="file" accept=".360project" onChange={(event) => {
        const file = event.target.files?.[0];
        if (file) void loadProject(file);
        event.target.value = '';
      }} />

      <header className="top-bar">
        <span className="top-bar-logo"><strong>360</strong><span>ImageStudio</span></span>
        <nav className="top-bar-tabs">
          <button className={`top-bar-tab ${activeTab === '360' ? 'active' : ''}`} disabled={state.workflow !== 'viewing'} onClick={() => setActiveTab('360')}>🌐 360 View</button>
          <button className={`top-bar-tab ${activeTab === 'flat' ? 'active' : ''}`} disabled={state.workflow !== 'viewing'} onClick={() => setActiveTab('flat')}>📐 Flat View</button>
        </nav>
        <details className="file-menu" ref={fileMenuRef}>
          <summary>☰ File</summary>
          <div className="file-menu-popover">
            <button onClick={() => { closeFileMenu(); imageInput.current?.click(); }}>📂 Open Image</button>
            <button disabled={isLoadingProject} onClick={() => { closeFileMenu(); projectInput.current?.click(); }}>📋 Load Project</button>
            <button disabled={!state.imagePath || isSavingProject} onClick={() => { closeFileMenu(); void saveProject(); }}>
              {isSavingProject ? <><span className="inline-spinner" /> Preparing Project…</> : <>💾 Download Project</>}
            </button>
            <button disabled={!state.imagePath || !committed} onClick={() => { closeFileMenu(); setExportOpen(true); }}>📤 Export Final</button>
            <button disabled={!state.imagePath} onClick={() => { closeFileMenu(); state.reset(); }}>↻ New</button>
          </div>
        </details>
        {fileName && <span className="top-bar-file"><strong>{fileName}</strong> · {state.imageWidth} × {state.imageHeight} {fileSize ? `· ${formatFileSize(fileSize)}` : ''}</span>}
        <button className="export-final-btn" disabled={!state.imagePath || !committed} onClick={() => setExportOpen(true)}>Export Final</button>
        <button className="logout-btn" onClick={() => void logout()}>Đăng xuất</button>
      </header>

      <main className="workspace">
        <Toolbar onExport={() => setExportOpen(true)} onSave={() => void saveProject()} isSaving={isSavingProject} />
        <section className="editor-area">
          {state.workflow === 'empty'
            ? <ImageDropZone onOpenFile={openFile} />
            : canvasWorkflow
              ? <CanvasEditor />
              : activeTab === '360' ? <Viewer360 /> : <FlatView />}
        </section>
        <LayerPanel />
      </main>
      <PromptBar />
      <footer className="status-bar">
        <span>{fileName ? `${fileName} — ${state.layers.length} layer(s)` : 'Chưa mở ảnh'}</span>
        <span>{state.workflow}</span>
      </footer>
      <ExportDialog open={exportOpen} onClose={() => setExportOpen(false)} />
      {isSavingProject && (
        <div className="project-save-progress" role="status" aria-live="polite">
          <span className="inline-spinner" />
          <span><strong>Đang chuẩn bị project…</strong><small>Đang đóng gói ảnh và dữ liệu, vui lòng chờ.</small></span>
        </div>
      )}
      {isLoadingProject && (
        <div className="project-load-overlay" role="status" aria-live="assertive" aria-busy="true">
          <div className="project-load-dialog">
            <span className="inline-spinner" />
            <div>
              <strong>Đang tải project…</strong>
              <small>{loadingProjectName || 'Đang tải lên và giải nén dữ liệu, vui lòng chờ.'}</small>
              <small>Project lớn có thể cần vài phút để xử lý.</small>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
